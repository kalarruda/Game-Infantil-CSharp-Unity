﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public GameObject caixaBarraca;
    //public Animator animCaixa;
    public GameObject fumaca;
    public GameObject fumacaAnimada;
    public GameObject martelo;
    public GameObject bandeira;
    public GameObject barracaDesarmada;
    public GameObject corda;
    public GameObject pregos;
    public GameObject barracaMontando;
    public GameObject fumacaAnimada2;
    public GameObject cordaTremendo;
    public GameObject barracaSemBandeira;
    public GameObject pregosTremendo;
    public GameObject pregosSeparados;
    public GameObject marteloTremendo;
    public GameObject marteloBatendo;
    public GameObject bandeiraTremendo;
    public GameObject barracaComBandeira;
    

    // Start is called before the first frame update
    void Start()
    {
        
        
    }


    // Update is called once per frame
    //public void Barraca()
    //{
    //    if (Input.GetButtonDown("botaoBarraca"))
    //    {
    //        this.Desaparece();
    //    }
    //}


    //public void Montando()
    //{
    //    if (montar == true)
    //    {
    //        MontarBarraca();

    //    }
    //    if (cordabool == false)
    //    {
    //        ColocandoCorda();
    //    }
    //    if (pregosTremendo == true && pregos==false)
    //    {
    //        ColocandoPregos();
    //    }
    //    if (marteloTremendo == true && martelo==false)
    //    {
    //        MartelandoBarraca();
    //    }
    //    if (bandeiraTremendo == true && bandeira==false)
    //    {
    //        ColocandoBandeira();
    //    }
    //}
   
    public void Desaparece()
    {
        this.caixaBarraca.SetActive(false);
        this.fumacaAnimada.SetActive(true);
        this.barracaDesarmada.SetActive(true);
        this.martelo.SetActive(true);
        this.pregos.SetActive(true);
        this.corda.SetActive(true);
        this.bandeira.SetActive(true);
    }

    public void MontarBarraca()
    {
        if (corda == true)
        {
            this.barracaMontando.SetActive(true);
            this.fumacaAnimada2.SetActive(true);
            this.barracaDesarmada.SetActive(false);
            this.corda.SetActive(false);
            this.cordaTremendo.SetActive(true);
        }         
      
    }

    public void ColocandoCorda()
    {
        if (cordaTremendo == true)
        {
            this.barracaSemBandeira.SetActive(true);
            this.barracaMontando.SetActive(false);
            this.cordaTremendo.SetActive(false);
            this.pregosTremendo.SetActive(true);
            this.pregos.SetActive(false);
        }              
               
    }

    public void ColocandoPregos()
    {
        if (pregosTremendo == true )
        {
            this.pregosTremendo.SetActive(false);
            this.pregosSeparados.SetActive(true);
            this.martelo.SetActive(false);
            this.marteloTremendo.SetActive(true);
        }
            
    }

    public void MartelandoBarraca()
    {
        if (marteloTremendo == true )
        {
            this.marteloTremendo.SetActive(false);
            this.marteloBatendo.SetActive(true);
            this.bandeira.SetActive(false);
            this.bandeiraTremendo.SetActive(true);
        }
            
    }

    public void ColocandoBandeira()
    {
        if (bandeiraTremendo == true )
        {
            this.bandeiraTremendo.SetActive(false);
            this.barracaSemBandeira.SetActive(false);
            this.barracaComBandeira.SetActive(true);
        }
            
    }
}


